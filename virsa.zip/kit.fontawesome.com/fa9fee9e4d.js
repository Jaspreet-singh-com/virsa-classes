window.FontAwesomeKitConfig = {
    "id": 74778786,
    "version": "6.7.2",
    "token": "fa9fee9e4d",
    "method": "css",
    "minify": {
        "enabled": true
    },
    "baseUrl": "https://ka-f.fontawesome.com",
    "license": "free",
    "asyncLoading": {
        "enabled": false
    },
    "autoA11y": {
        "enabled": true
    },
    "baseUrlKit": "https://kit.fontawesome.com",
    "detectConflictsUntil": null,
    "iconUploads": {},
    "startupFilename": "free.min.css",
    "v4FontFaceShim": {
        "enabled": true
    },
    "v4shim": {
        "enabled": true
    },
    "v5FontFaceShim": {
        "enabled": true
    }
};
! function(t) {
    "function" == typeof define && define.amd ? define("kit-loader", t) : t()
}((function() {
    "use strict";

    function t(t, e) {
        var n = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(t);
            e && (o = o.filter((function(e) {
                return Object.getOwnPropertyDescriptor(t, e).enumerable
            }))), n.push.apply(n, o)
        }
        return n
    }

    function e(e) {
        for (var n = 1; n < arguments.length; n++) {
            var r = null != arguments[n] ? arguments[n] : {};
            n % 2 ? t(Object(r), !0).forEach((function(t) {
                o(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : t(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function n(t) {
        return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }

    function o(t, e, n) {
        return (e = function(t) {
            var e = function(t, e) {
                if ("object" != typeof t || null === t) return t;
                var n = t[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var o = n.call(t, e || "default");
                    if ("object" != typeof o) return o;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === e ? String : Number)(t)
            }(t, "string");
            return "symbol" == typeof e ? e : String(e)
        }(e)) in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function r(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != n) {
                var o, r, i, a, c = [],
                    l = !0,
                    u = !1;
                try {
                    if (i = (n = n.call(t)).next, 0 === e) {
                        if (Object(n) !== n) return;
                        l = !1
                    } else
                        for (; !(l = (o = i.call(n)).done) && (c.push(o.value), c.length !== e); l = !0);
                } catch (t) {
                    u = !0, r = t
                } finally {
                    try {
                        if (!l && null != n.return && (a = n.return(), Object(a) !== a)) return
                    } finally {
                        if (u) throw r
                    }
                }
                return c
            }
        }(t, e) || i(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function i(t, e) {
        if (t) {
            if ("string" == typeof t) return a(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? a(t, e) : void 0
        }
    }

    function a(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
        return o
    }
    var c, l, u, f, s, d = "thumbprint",
        h = (o(c = {}, "classic", "Classic"), o(c, "duotone", "Duotone"), o(c, "sharp", "Sharp"), o(c, "sharp-duotone", "Sharp Duotone"), o(c, "chisel", "Chisel"), o(c, "etch", "Etch"), o(c, "jelly", "Jelly"), o(c, "jelly-duo", "Jelly Duo"), o(c, "jelly-fill", "Jelly Fill"), o(c, "notdog", "Notdog"), o(c, "notdog-duo", "Notdog Duo"), o(c, "slab", "Slab"), o(c, "slab-press", "Slab Press"), o(c, "thumbprint", "Thumbprint"), o(c, "utility", "Utility"), o(c, "utility-duo", "Utility Duo"), o(c, "utility-fill", "Utility Fill"), o(c, "whiteboard", "Whiteboard"), ["fak", "fa-kit", "fakd", "fa-kit-duotone"]),
        p = (o(l = {}, "kit", "Kit"), o(l, "kit-duotone", "Kit Duotone"), "duotone-group"),
        b = "swap-opacity",
        y = "primary",
        m = "secondary",
        v = (o(u = {}, "classic", "Classic"), o(u, "duotone", "Duotone"), o(u, "sharp", "Sharp"), o(u, "sharp-duotone", "Sharp Duotone"), o(u, "chisel", "Chisel"), o(u, "etch", "Etch"), o(u, "jelly", "Jelly"), o(u, "jelly-duo", "Jelly Duo"), o(u, "jelly-fill", "Jelly Fill"), o(u, "notdog", "Notdog"), o(u, "notdog-duo", "Notdog Duo"), o(u, "slab", "Slab"), o(u, "slab-press", "Slab Press"), o(u, "thumbprint", "Thumbprint"), o(u, "utility", "Utility"), o(u, "utility-duo", "Utility Duo"), o(u, "utility-fill", "Utility Fill"), o(u, "whiteboard", "Whiteboard"), o(f = {}, "kit", "Kit"), o(f, "kit-duotone", "Kit Duotone"), ["fa", "fas", "far", "fal", "fat", "fad", "fadr", "fadl", "fadt", "fab", "fass", "fasr", "fasl", "fast", "fasds", "fasdr", "fasdl", "fasdt", "faslr", "faslpr", "fawsb", "fatl", "fans", "fands", "faes", "fajr", "fajfr", "fajdr", "facr", "fausb", "faudsb", "faufsb"].concat(["fa-classic", "fa-duotone", "fa-sharp", "fa-sharp-duotone", "fa-thumbprint", "fa-whiteboard", "fa-notdog", "fa-notdog-duo", "fa-chisel", "fa-etch", "fa-jelly", "fa-jelly-fill", "fa-jelly-duo", "fa-slab", "fa-slab-press", "fa-utility", "fa-utility-duo", "fa-utility-fill"], ["fa-solid", "fa-regular", "fa-light", "fa-thin", "fa-duotone", "fa-brands", "fa-semibold"])),
        g = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        w = g.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]);
    [].concat((s = Object.keys({
        classic: ["fas", "far", "fal", "fat", "fad"],
        duotone: ["fadr", "fadl", "fadt"],
        sharp: ["fass", "fasr", "fasl", "fast"],
        "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
        slab: ["faslr"],
        "slab-press": ["faslpr"],
        whiteboard: ["fawsb"],
        thumbprint: ["fatl"],
        notdog: ["fans"],
        "notdog-duo": ["fands"],
        etch: ["faes"],
        jelly: ["fajr"],
        "jelly-fill": ["fajfr"],
        "jelly-duo": ["fajdr"],
        chisel: ["facr"],
        utility: ["fausb"],
        "utility-duo": ["faudsb"],
        "utility-fill": ["faufsb"]
    }), function(t) {
        if (Array.isArray(t)) return a(t)
    }(s) || function(t) {
        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
    }(s) || i(s) || function() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }()), ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"], ["aw", "fw", "pull-left", "pull-right"], ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "border", "fade", "beat-fade", "bounce", "flip-both", "flip-horizontal", "flip-vertical", "flip", "inverse", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "stack-1x", "stack-2x", "stack", "ul", "width-auto", "width-fixed", p, b, y, m]).concat(g.map((function(t) {
        return "".concat(t, "x")
    }))).concat(w.map((function(t) {
        return "w-".concat(t)
    })));

    function j(t, e) {
        var n = e && e.addOn || "",
            o = e && e.baseFilename || t.license + n,
            r = e && e.minify ? ".min" : "",
            i = e && e.fileSuffix || t.method,
            a = e && e.filename ? e.filename : o + r + "." + i,
            c = e && e.subdir || t.method;
        return t.baseUrl + "/releases/" + ("latest" === t.version ? "latest" : "v".concat(t.version)) + "/" + c + "/" + a
    }

    function A(t, e) {
        var n = e || ["fa"],
            o = "." + Array.prototype.join.call(n, ",."),
            r = t.querySelectorAll(o);
        Array.prototype.forEach.call(r, (function(e) {
            var n = e.getAttribute("title");
            e.setAttribute("aria-hidden", "true");
            var o = !e.nextElementSibling || !e.nextElementSibling.classList.contains("sr-only");
            if (n && o) {
                var r = t.createElement("span");
                r.innerHTML = n, r.classList.add("sr-only"), e.parentNode.insertBefore(r, e.nextSibling)
            }
        }))
    }
    var S, O = function() {},
        E = "undefined" != typeof global && void 0 !== global.process && "function" == typeof global.process.emit,
        P = "undefined" == typeof setImmediate ? setTimeout : setImmediate,
        F = [];

    function k() {
        for (var t = 0; t < F.length; t++) F[t][0](F[t][1]);
        F = [], S = !1
    }

    function _(t, e) {
        F.push([t, e]), S || (S = !0, P(k, 0))
    }

    function C(t) {
        var e = t.owner,
            n = e._state,
            o = e._data,
            r = t[n],
            i = t.then;
        if ("function" == typeof r) {
            n = "fulfilled";
            try {
                o = r(o)
            } catch (t) {
                I(i, t)
            }
        }
        U(i, o) || ("fulfilled" === n && x(i, o), "rejected" === n && I(i, o))
    }

    function U(t, e) {
        var o;
        try {
            if (t === e) throw new TypeError("A promises callback cannot return that same promise.");
            if (e && ("function" == typeof e || "object" === n(e))) {
                var r = e.then;
                if ("function" == typeof r) return r.call(e, (function(n) {
                    o || (o = !0, e === n ? D(t, n) : x(t, n))
                }), (function(e) {
                    o || (o = !0, I(t, e))
                })), !0
            }
        } catch (e) {
            return o || I(t, e), !0
        }
        return !1
    }

    function x(t, e) {
        t !== e && U(t, e) || D(t, e)
    }

    function D(t, e) {
        "pending" === t._state && (t._state = "settled", t._data = e, _(L, t))
    }

    function I(t, e) {
        "pending" === t._state && (t._state = "settled", t._data = e, _(N, t))
    }

    function T(t) {
        t._then = t._then.forEach(C)
    }

    function L(t) {
        t._state = "fulfilled", T(t)
    }

    function N(t) {
        t._state = "rejected", T(t), !t._handled && E && global.process.emit("unhandledRejection", t._data, t)
    }

    function K(t) {
        global.process.emit("rejectionHandled", t)
    }

    function M(t) {
        if ("function" != typeof t) throw new TypeError("Promise resolver " + t + " is not a function");
        if (this instanceof M == !1) throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.");
        this._then = [],
            function(t, e) {
                function n(t) {
                    I(e, t)
                }
                try {
                    t((function(t) {
                        x(e, t)
                    }), n)
                } catch (t) {
                    n(t)
                }
            }(t, this)
    }
    M.prototype = {
        constructor: M,
        _state: "pending",
        _then: null,
        _data: void 0,
        _handled: !1,
        then: function(t, e) {
            var n = {
                owner: this,
                then: new this.constructor(O),
                fulfilled: t,
                rejected: e
            };
            return !e && !t || this._handled || (this._handled = !0, "rejected" === this._state && E && _(K, this)), "fulfilled" === this._state || "rejected" === this._state ? _(C, n) : this._then.push(n), n.then
        },
        catch: function(t) {
            return this.then(null, t)
        }
    }, M.all = function(t) {
        if (!Array.isArray(t)) throw new TypeError("You must pass an array to Promise.all().");
        return new M((function(e, n) {
            var o = [],
                r = 0;

            function i(t) {
                return r++,
                    function(n) {
                        o[t] = n, --r || e(o)
                    }
            }
            for (var a, c = 0; c < t.length; c++)(a = t[c]) && "function" == typeof a.then ? a.then(i(c), n) : o[c] = a;
            r || e(o)
        }))
    }, M.race = function(t) {
        if (!Array.isArray(t)) throw new TypeError("You must pass an array to Promise.race().");
        return new M((function(e, n) {
            for (var o, r = 0; r < t.length; r++)(o = t[r]) && "function" == typeof o.then ? o.then(e, n) : e(o)
        }))
    }, M.resolve = function(t) {
        return t && "object" === n(t) && t.constructor === M ? t : new M((function(e) {
            e(t)
        }))
    }, M.reject = function(t) {
        return new M((function(e, n) {
            n(t)
        }))
    };
    var R = "function" == typeof Promise ? Promise : M;

    function J(t, e) {
        var n = e.fetch,
            o = e.XMLHttpRequest,
            r = e.token,
            i = t;
        return r && ! function(t) {
            return t.indexOf("kit-upload.css") > -1
        }(t) && ("URLSearchParams" in window ? (i = new URL(t)).searchParams.set("token", r) : i = i + "?token=" + encodeURIComponent(r)), i = i.toString(), new R((function(t, e) {
            if ("function" == typeof n) n(i, {
                mode: "cors",
                cache: "default"
            }).then((function(t) {
                if (t.ok) return t.text();
                throw new Error("")
            })).then((function(e) {
                t(e)
            })).catch(e);
            else if ("function" == typeof o) {
                var r = new o;
                r.addEventListener("loadend", (function() {
                    this.responseText ? t(this.responseText) : e(new Error(""))
                }));
                ["abort", "error", "timeout"].map((function(t) {
                    r.addEventListener(t, (function() {
                        e(new Error(""))
                    }))
                })), r.open("GET", i), r.send()
            } else {
                e(new Error(""))
            }
        }))
    }

    function H(t, e, n) {
        var o = t;
        return [
            [/(url\("?)\.\.\/\.\.\/\.\./g, function(t, n) {
                return "".concat(n).concat(e)
            }],
            [/(url\("?)\.\.\/webfonts/g, function(t, o) {
                return "".concat(o).concat(e, "/releases/v").concat(n, "/webfonts")
            }],
            [/(url\("?)https:\/\/kit-free([^.])*\.fontawesome\.com/g, function(t, n) {
                return "".concat(n).concat(e)
            }]
        ].forEach((function(t) {
            var e = r(t, 2),
                n = e[0],
                i = e[1];
            o = o.replace(n, i)
        })), o
    }

    function q(t, n) {
        var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : function() {},
            r = n.document || r,
            i = A.bind(A, r, [].concat(v, h.map((function(t) {
                return "fa-".concat(t)
            }))));
        t.autoA11y.enabled && o(i);
        var a = t.subsetPath && t.baseUrl + "/" + t.subsetPath,
            c = [];
        if (a ? c.push({
                id: "fa-main",
                addOn: void 0,
                url: a
            }) : c.push({
                id: "fa-main",
                addOn: void 0,
                url: j(t, {
                    filename: t.startupFilename,
                    minify: t.minify.enabled
                })
            }), t.v4shim && t.v4shim.enabled && c.push({
                id: "fa-v4-shims",
                addOn: "-v4-shims"
            }), t.v5FontFaceShim && t.v5FontFaceShim.enabled && c.push({
                id: "fa-v5-font-face",
                addOn: "-v5-font-face"
            }), t.v4FontFaceShim && t.v4FontFaceShim.enabled && c.push({
                id: "fa-v4-font-face",
                addOn: "-v4-font-face"
            }), !a && t.customIconsCssPath) {
            var l = t.customIconsCssPath.indexOf("kit-upload.css") > -1 ? t.baseUrlKit : t.baseUrl,
                u = l + "/" + t.customIconsCssPath;
            c.push({
                id: "fa-kit-upload",
                url: u
            })
        }
        var f = c.map((function(o) {
            return new R((function(r, i) {
                var a = o.url || j(t, {
                        addOn: o.addOn,
                        minify: t.minify.enabled
                    }),
                    c = {
                        id: o.id
                    },
                    l = t.subset ? c : e(e(e({}, n), c), {}, {
                        baseUrl: t.baseUrl,
                        version: t.version,
                        id: o.id,
                        contentFilter: function(t, e) {
                            return H(t, e.baseUrl, e.version)
                        }
                    });
                J(a, n).then((function(t) {
                    r(X(t, l))
                })).catch(i)
            }))
        }));
        return R.all(f)
    }

    function X(t, e) {
        var n = e.contentFilter || function(t, e) {
                return t
            },
            o = document.createElement("style"),
            r = document.createTextNode(n(t, e));
        return o.appendChild(r), o.media = "all", e.id && o.setAttribute("id", e.id), e && e.detectingConflicts && e.detectionIgnoreAttr && o.setAttributeNode(document.createAttribute(e.detectionIgnoreAttr)), o
    }

    function B(t, n) {
        n.autoA11y = t.autoA11y.enabled, "pro" === t.license && (n.autoFetchSvg = !0, n.fetchSvgFrom = t.baseUrl + "/releases/" + ("latest" === t.version ? "latest" : "v".concat(t.version)) + "/svgs", n.fetchUploadedSvgFrom = t.uploadsUrl);
        var o = [];
        return t.v4shim.enabled && o.push(new R((function(o, r) {
            J(j(t, {
                addOn: "-v4-shims",
                minify: t.minify.enabled
            }), n).then((function(t) {
                o(W(t, e(e({}, n), {}, {
                    id: "fa-v4-shims"
                })))
            })).catch(r)
        }))), o.push(new R((function(o, r) {
            J(t.subsetPath && t.baseUrl + "/" + t.subsetPath || j(t, {
                filename: t.startupFilename,
                minify: t.minify.enabled
            }), n).then((function(t) {
                var r = W(t, e(e({}, n), {}, {
                    id: "fa-main"
                }));
                o(function(t, e) {
                    var n = e && void 0 !== e.autoFetchSvg ? e.autoFetchSvg : void 0,
                        o = e && void 0 !== e.autoA11y ? e.autoA11y : void 0;
                    void 0 !== o && t.setAttribute("data-auto-a11y", o ? "true" : "false");
                    n && (t.setAttributeNode(document.createAttribute("data-auto-fetch-svg")), t.setAttribute("data-fetch-svg-from", e.fetchSvgFrom), t.setAttribute("data-fetch-uploaded-svg-from", e.fetchUploadedSvgFrom));
                    return t
                }(r, n))
            })).catch(r)
        }))), R.all(o)
    }

    function W(t, e) {
        var n = document.createElement("SCRIPT"),
            o = document.createTextNode(t);
        return n.appendChild(o), n.referrerPolicy = "strict-origin", e.id && n.setAttribute("id", e.id), e && e.detectingConflicts && e.detectionIgnoreAttr && n.setAttributeNode(document.createAttribute(e.detectionIgnoreAttr)), n
    }

    function Y(t) {
        var e, n = [],
            o = document,
            r = o.documentElement.doScroll,
            i = (r ? /^loaded|^c/ : /^loaded|^i|^c/).test(o.readyState);
        i || o.addEventListener("DOMContentLoaded", e = function() {
            for (o.removeEventListener("DOMContentLoaded", e), i = 1; e = n.shift();) e()
        }), i ? setTimeout(t, 0) : n.push(t)
    }

    function z(t) {
        "undefined" != typeof MutationObserver && new MutationObserver(t).observe(document, {
            childList: !0,
            subtree: !0
        })
    }
    try {
        if (window.FontAwesomeKitConfig) {
            var G = window.FontAwesomeKitConfig,
                $ = {
                    detectingConflicts: G.detectConflictsUntil && new Date <= new Date(G.detectConflictsUntil),
                    detectionIgnoreAttr: "data-fa-detection-ignore",
                    fetch: window.fetch,
                    token: G.token,
                    XMLHttpRequest: window.XMLHttpRequest,
                    document: document
                },
                Q = document.currentScript,
                V = Q ? Q.parentElement : document.head;
            (function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return "js" === t.method ? B(t, e) : "css" === t.method ? q(t, e, (function(t) {
                    Y(t), z(t)
                })) : void 0
            })(G, $).then((function(t) {
                t.map((function(t) {
                    try {
                        V.insertBefore(t, Q ? Q.nextSibling : null)
                    } catch (e) {
                        V.appendChild(t)
                    }
                })), $.detectingConflicts && Q && Y((function() {
                    Q.setAttributeNode(document.createAttribute($.detectionIgnoreAttr));
                    var t = function(t, e) {
                        var n = document.createElement("script");
                        return e && e.detectionIgnoreAttr && n.setAttributeNode(document.createAttribute(e.detectionIgnoreAttr)), n.src = j(t, {
                            baseFilename: "conflict-detection",
                            fileSuffix: "js",
                            subdir: "js",
                            minify: t.minify.enabled
                        }), n
                    }(G, $);
                    document.body.appendChild(t)
                }))
            })).catch((function(t) {
                console.error("".concat("Font Awesome Kit:", " ").concat(t))
            }))
        }
    } catch (d) {
        console.error("".concat("Font Awesome Kit:", " ").concat(d))
    }
}));
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sikhya Classes</title>
	<link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="https://kit.fontawesome.com/fa9fee9e4d.js" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  	<script src='js/tinymce/tinymce.min.js'></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
    <link rel="stylesheet" type="text/css" href="css/dhtmlx.css">
    <style>
    	#toast-container > div { opacity: 1; }

    </style>
</head>
<body>
<div class="container topbar">
	<div class="col-md-3 col-xs-5">
		<a href="https://sikhyaclasses.com"><img src="images/logo.png" class="logo" alt=""></a>
	</div>
	<div class="col-md-3 col-xs-7 col-md-offset-3 cinfo">
		<i class="fa-solid fa-phone fa-lg fa-fw"></i>
		<span>Call Now</span>
		<p>+1 204-463-0110</p>
	</div>
	<div class="col-md-3 col-xs-12 cinfo cinfo2">
		<i class="fa-solid fa-envelope-open-text fa-lg fa-fw"></i> 
		<span>Email</span>
		<p>info@radiodhamaal.ca</p>
	</div>
</div>	
<div class="clearfix"></div>
<nav class="navbar mymenu">
	<div class="container">
		<div class="navbar-header">
			 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
      		  <i class="fa-solid fa-bars fa-2x" style="color:#ffffff;"></i>
			</button>
		</div>

		<div class="collapse navbar-collapse" id="myNavbar">
		<ul class="nav navbar-nav navbar-right">
			<li><a href="https://sikhyaclasses.com">Home</a></li>
			<li><a href="courses.php">Programs</a></li>
			<!-- <li><a href="apply-now.php">Apply Now</a></li> -->
			<li><a href="about.php">About Us</a></li>
			<li><a href="contact.php">Contact Us</a></li>
								<li><a href="login.php">Student Login</a></li>
					</ul>
		</div>
	</div>
</nav>
<div class="cleafix"></div><div class="container intro  ">

	<h2 class="heading text-center"><span>All Programs</span></h2>
	
		<div class="col-md-4">
		<div class="pro">
		<a href="program.php?pid=1"><img src="posters/22012025084357prog1.jpg"  alt="Sikhya Classes"></a>

		
		</div>
	</div>

	<div class="col-md-7 col-md-offset-1">
		<h3>Course : Sikhya Program</h3>
		<h4><span style="display: inline-block; width: 95px;">Language </span>: Punjabi</h4>
		<h4><span style="display: inline-block; width: 95px;">Level </span>: Beginners</h4>
		<h4><span style="display: inline-block; width: 95px;">Duration </span>: 6 Months</h4>

		
		<!-- <h3>Fee: $			<del style="font-size: 15px;">$</del> / 		</h3> -->
		<a href="tel:+12044630110>" class="button"><i class="fa-solid fa-phone"></i> Call Now</a>
		<a href="apply-now.php?pid=1" class="button">Apply Now</a>
		<hr>
		<div class="desc">
			<p>Our online Punjabi classes are designed for learners of all ages and backgrounds. Whether you're reconnecting with your roots, learning for cultural interest, or enhancing your language skills, our expert instructors provide personalized lessons tailored to your level - beginner, intermediate, or advanced.</p>		</div>
	</div>
	<div class="clearfix"></div>	<hr>
			
		
	


	
</div>


<div class="clearfix"></div>
<div class="container intro wel">
	
	<h2 class="heading text-center"><span>How It Works!</span></h3>
	<div class="col-md-4 text-center">
		<div class="how">
		<img src="images/step1.jpg" alt="Sikhya Classes - Online Punjabi classes">
		<h3>Register Online</h3>
		<p>Go to the Sikhya Classes website and fill up Registeration form.</p>
		</div>
	</div>

	<div class="col-md-4 text-center">
		<div class="how">
		<img src="images/step2.jpg" alt="Sikhya Classes - Online Punjabi classes">
		<h3>Make  Payment</h3>
		<p>We will contact you to make payment of class fee.</p>
		</div>
	</div>

	<div class="col-md-4 text-center">
		<div class="how">
		<img src="images/step3.jpg" alt="Sikhya Classes - Online Punjabi classes">
		<h3>Start Online Class</h3>
		<p>Start your live online classes from home or anywhere in world.</p>
		</div>
	</div>


</div>


<div class="clearfix"></div>
<div class="col-md-12 footer">
	<div class="container">
		<div class="col-md-3">
			<img src="images/logow.jpg" width="220" style="padding: 10px;background: #fff;" alt="">
			<p class="tag">Promoting our culture across the world.</p>
		</div>

		<div class="col-md-2 col-md-offset-1 links">
			<h4>Links</h4>
			<ul>                                        
                <li><a href="index.php"><i class="fa-solid fa-caret-right fa-fw"></i> Home</a></li>
				<li><a href="courses.php"><i class="fa-solid fa-caret-right fa-fw"></i> Programs</a></li>
				<li><a href="about.php"><i class="fa-solid fa-caret-right fa-fw"></i> About Us</a></li>
				<li><a href="contact.php"><i class="fa-solid fa-caret-right fa-fw"></i> Contact Us</a></li>
			</ul>
		</div>
		<div class="col-md-3 links">
			<h4>Policies</h4>
			<ul>                                        
                <li><a href="privacy-policy.php"><i class="fa-solid fa-caret-right fa-fw"></i> Privacy Policy</a></li>
				<!-- <li><a href="terms.php"><i class="fa-solid fa-caret-right fa-fw"></i> Terms & Conditions</a></li>
				<li><a href="refund.php"><i class="fa-solid fa-caret-right fa-fw"></i> Refund Policy</a></li> -->
			</ul>
		</div>
		<div class="col-md-3 links">
			<h4>Get in Touch</h4>
				<p><i class="fa-solid fa-phone fa-lg fa-fw"></i> +1 204-463-0110</p>
				<p><i class="fa-solid fa-envelope-open-text fa-lg fa-fw"></i> info@radiodhamaal.ca</p>
				<p><i class="fa-solid fa-location-dot fa-lg fa-fw"></i> 96 Wheatfield Rd WINNIPEG, MB R3C2E6</p>
		</div>
	</div>

	<div class="clearfix"></div>
<a href="http://technopediasolutions.com/" target="_blank" style="color:#333333">Technopedia Solutions</a>
</div>

<div class="col-md-offset-11 col-md-1 col-xs-offset-9 col-xs-3 text-right navbar-fixed-bottom  " style="margin-bottom:5px">

<a href="https://api.whatsapp.com/send?phone=12044630110" target="_blank" style="color:#00ff00;">  <img src="images/whatsapp.png" width="60" alt="Sikhya Classes"> </a>
</div>





</body>
<script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'},{'ap':'cpsh-oh'},{'server':'p3plzcpnl504913'},{'dcenter':'p3'},{'cp_id':'9875948'},{'cp_cl':'8'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/traffic-assets/js/tccl.min.js'></script></html>